Sarah Abrahamson
abrahs3
Lab 3 Readme

Part 1 - https://github.com/sarahabrahamson/ITWS4500

Part 2 -

Server - https://dashboard.heroku.com/apps/grogro/resources
Github - https://github.com/rickrizzo/GroGro
My fork - https://github.com/sarahabrahamson/GroGro
Bug tracker - Followed bugzilla installation guide. It didn't work. Installed MantisBT instead.


