Sarah Abrahamson
abrahs3
Lab 2 - Weather API

I used the OpenWeatherMap API.

Sometimes the calls to the APIs fail, so just refresh until they both load. I couldn't figure out why that was happening.

I display the current weather, humidity, wind speed/direction, and today's High and Low temperatures. 

Using a list and the daily forecast API, I display data for the next 4 days. When you click on a certain day, a nested list will appear to display the temperatures for Morning, Evening, and Night. 

